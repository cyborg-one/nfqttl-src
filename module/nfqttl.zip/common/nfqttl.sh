#!/system/bin/sh

while [ ""`getprop dev.bootcomplete` != "1" ] ; do sleep 3; done

echo "\$0 $0" >> /data/local/tmp/testenveronment
echo "\${0\%\/\*} ${0%/*}" >> /data/local/tmp/testenveronment
echo "\$MODDIR $MODDIR" >> /data/local/tmp/testenveronment
echo "\$PATH $PATH" >> /data/local/tmp/testenveronment
echo "uname `uname -a`" >> /data/local/tmp/testenveronment
echo "iptables `iptables -t mangle -vnL FORWARD`" >> /data/local/tmp/testenveronment
echo "ps `/data/adb/magisk/busybox ps | grep nfqttl`" >> /data/local/tmp/testenveronment
echo "pwd `pwd`" >> /data/local/tmp/testenveronment
#iptables -t mangle -D FORWARD -i wlan0 -j NFQUEUE --queue-num 201
#iptables -t mangle -A FORWARD -i wlan0 -j NFQUEUE --queue-num 201

#iptables -t mangle -D FORWARD -o wlan0 -m ttl --ttl 1 -j NFQUEUE --queue-num 201
#iptables -t mangle -A FORWARD -o wlan0 -m ttl --ttl 1 -j NFQUEUE --queue-num 201

#iptables -t nat -A POSTROUTING ! -o wlan0 -j MASQUERADE
#ip6tables -t filter -I FORWARD -j REJECT

MODDIR=${0%/*}
echo "\$MODDIR/nfqttl " >> /data/local/tmp/testenveronment
$MODDIR/nfqttl >> /data/local/tmp/testenveronment
echo "/data/adb/modules/nfqttl/system/bin/nfqttl `/data/adb/modules/nfqttl/system/bin/nfqttl` " >> /data/local/tmp/tes

