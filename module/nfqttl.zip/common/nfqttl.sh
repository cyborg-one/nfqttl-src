#!/system/bin/sh

iptables -t mangle -D FORWARD -j NFQUEUE --queue-num 201
iptables -t mangle -A FORWARD -j NFQUEUE --queue-num 201

#iptables -t mangle -D OUTPUT -o wlan0 -j NFQUEUE --queue-num 202
#iptables -t mangle -A OUTPUT -o wlan0 -j NFQUEUE --queue-num 202

ip6tables -t mangle -D FORWARD -j NFQUEUE --queue-num 201
ip6tables -t mangle -A FORWARD -j NFQUEUE --queue-num 201

#ip6tables -t mangle -D OUTPUT -o wlan0 -j NFQUEUE --queue-num 202
#ip6tables -t mangle -A OUTPUT -o wlan0 -j NFQUEUE --queue-num 202
echo 65 > /proc/sys/net/ipv6/conf/wlan0/hop_limit
	while ! [ `pgrep -x nfqttl` ] ; do
#	    $MODDIR/system/bin/nfqttl &&  $MODDIR/system/bin/nfqttl --ttl=65 --num-queue=202 && sleep 1
	    $MODDIR/system/bin/nfqttl && sleep 1
	done
        t=`cat /proc/sys/net/ipv4/ip_default_ttl`
        while true ; do
            if ifconfig | grep wlan0 && [ $t -eq 64 ]
                then
                echo wlan0 on $t
                t=65
                echo $t > /proc/sys/net/ipv4/ip_default_ttl
                echo wlan0 on $t
            elif ! ifconfig | grep wlan0 &&  [ $t -eq 65 ]
                then echo wlan0 off $t
                t=64
                echo $t > /proc/sys/net/ipv4/ip_default_ttl
                echo wlan0 off $t
            else
            echo else $t
            fi
            sleep 3
        done

