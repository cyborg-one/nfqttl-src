#!/system/bin/sh

MODDIR=${0%/*}

iptables -t mangle -D FORWARD ! -o wlan0 -j NFQUEUE --queue-num 201
iptables -t mangle -A FORWARD ! -o wlan0 -j NFQUEUE --queue-num 201

iptables -t mangle -D PREROUTING ! -i wlan0 -m ttl --ttl 1 -j NFQUEUE --queue-num 201
iptables -t mangle -A PREROUTING ! -i wlan0 -m ttl --ttl 1 -j NFQUEUE --queue-num 201

ip6tables -t mangle -D FORWARD ! -o wlan0 -j NFQUEUE --queue-num 201
ip6tables -t mangle -A FORWARD ! -o wlan0 -j NFQUEUE --queue-num 201

ip6tables -t mangle -D PREROUTING ! -i wlan0 -m hl --hl-eq 1 -j NFQUEUE --queue-num 201
ip6tables -t mangle -A PREROUTING ! -i wlan0 -m hl --hl-eq 1 -j NFQUEUE --queue-num 201


iptables -t nat -D FORWARD -p udp --dport 53 -j DNAT --to 8.8.8.8
iptables -t nat -A FORWARD -p udp --dport 53 -j DNAT --to 8.8.8.8

iptables -t nat -D FORWARD -p tcp --dport 53 -j DNAT --to 8.8.8.8
iptables -t nat -A FORWARD -p tcp --dport 53 -j DNAT --to 8.8.8.8


ip6tables -t nat -D FORWARD -p udp --dport 53 -j DNAT --to 2001:4860:4860::8888
ip6tables -t nat -A FORWARD -p udp --dport 53 -j DNAT --to 2001:4860:4860::8888

ip6tables -t nat -D FORWARD -p tcp --dport 53 -j DNAT --to 2001:4860:4860::8888
ip6tables -t nat -A FORWARD -p tcp --dport 53 -j DNAT --to 2001:4860:4860::8888

$MODDIR/nfqttl &