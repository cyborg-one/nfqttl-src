#!/system/bin/sh
#set -x
while [ ""`getprop dev.bootcomplete` != "1" ] ; do sleep 3; done
iptables -t mangle -D FORWARD -j NFQUEUE --queue-num 201
iptables -t mangle -A FORWARD -j NFQUEUE --queue-num 201

ip6tables -t mangle -D FORWARD -j NFQUEUE --queue-num 201
ip6tables -t mangle -A FORWARD -j NFQUEUE --queue-num 201

#iptables -t mangle -D OUTPUT -o wlan0 -j NFQUEUE --queue-num 202
#iptables -t mangle -A OUTPUT -o wlan0 -j NFQUEUE --queue-num 202

#ip6tables -t mangle -D OUTPUT -o wlan0 -j NFQUEUE --queue-num 202
#ip6tables -t mangle -A OUTPUT -o wlan0 -j NFQUEUE --queue-num 202

#echo "65" > /proc/sys/net/ipv6/conf/wlan0/hop_limit
#    while ! [ `pgrep -x nfqttl` ] ; do
#	while [ `ps` != *nfqttl* ] ; do
#	    $MODDIR/system/bin/nfqttl &&  $MODDIR/system/bin/nfqttl --ttl=65 --num-queue=202 && sleep 1
#	    $MODDIR/system/bin/nfqttl && sleep 1
#	done

$MODDIR/system/bin/nfqttl
t="64"
while true ; do
    if [ `cat /sys/class/net/wlan0/link_mode` = "1" ] &&  [ `cat /sys/class/net/wlan0/operstate` = "up" ] &&  [ `cat /proc/sys/net/ipv4/ip_default_ttl` = $t ] ;
	then
	t="65"
	echo $t > /proc/sys/net/ipv4/ip_default_ttl
	echo $t > /proc/sys/net/ipv6/conf/wlan0/hop_limit
    elif [ `cat /sys/class/net/wlan0/link_mode` != "1" ] ||  [ `cat /sys/class/net/wlan0/operstate` != "up" ] &&  [ `cat /proc/sys/net/ipv4/ip_default_ttl` = $t ] ;
	then
        t="64"
        echo $t > /proc/sys/net/ipv4/ip_default_ttl
	echo $t > /proc/sys/net/ipv6/conf/wlan0/hop_limit
    fi
    sleep 3
done