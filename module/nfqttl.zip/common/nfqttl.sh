#!/system/bin/sh

MODDIR=${0%/*}

iptables -t mangle -D FORWARD -i wlan0 -j NFQUEUE --queue-num 201
iptables -t mangle -A FORWARD -i wlan0 -j NFQUEUE --queue-num 201

iptables -t mangle -D PREROUTING ! -i wlan0 -m ttl --ttl 1 -j NFQUEUE --queue-num 201
iptables -t mangle -A PREROUTING ! -i wlan0 -m ttl --ttl 1 -j NFQUEUE --queue-num 201

ip6tables -t mangle -D FORWARD -i wlan0 -j NFQUEUE --queue-num 201
ip6tables -t mangle -A FORWARD -i wlan0 -j NFQUEUE --queue-num 201

ip6tables -t mangle -D PREROUTING ! -i wlan0 -m hl --hl-eq 1 -j NFQUEUE --queue-num 201
ip6tables -t mangle -A PREROUTING ! -i wlan0 -m hl --hl-eq 1 -j NFQUEUE --queue-num 201

$MODDIR/nfqttl &