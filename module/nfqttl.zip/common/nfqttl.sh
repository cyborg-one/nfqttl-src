#!/system/bin/sh

while [ ""`getprop dev.bootcomplete` != "1" ] ; do sleep 3; done

MODDIR=${0%/*}

iptables -t mangle -D FORWARD -i wlan0 -j NFQUEUE --queue-num 201
iptables -t mangle -A FORWARD -i wlan0 -j NFQUEUE --queue-num 201

iptables -t mangle -D FORWARD -o wlan0 -m ttl --ttl 1 -j NFQUEUE --queue-num 201
iptables -t mangle -A FORWARD -o wlan0 -m ttl --ttl 1 -j NFQUEUE --queue-num 201


$MODDIR/nfqttl &