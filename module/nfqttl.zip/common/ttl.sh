#!/system/bin/sh
while [ ""`getprop dev.bootcomplete` != "1" ] ; do sleep 3; done
iptables -t mangle -D FORWARD -j TTL --ttl-set 64
iptables -t mangle -A FORWARD -j TTL --ttl-set 64

iptables -t mangle -D OUTPUT -o wlan0 -j TTL --ttl-set 65
iptables -t mangle -A OUTPUT -o wlan0 -j TTL --ttl-set 65

ip6tables -t filter -I FORWARD -j REJECT
#ip6tables -t mangle -D FORWARD -j HL --hl-set 64
#ip6tables -t mangle -A FORWARD -j HL --hl-set 64

#ip6tables -t mangle -D OUTPUT -o wlan0 -j HL --hl-set 65
#ip6tables -t mangle -A OUTPUT -o wlan0 -j HL --hl-set 65