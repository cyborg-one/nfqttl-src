#!/system/bin/sh
iptables -t mangle -D PREROUTING ! -i wlan0 -m ttl --ttl 1 -j TTL --ttl-set 64
iptables -t mangle -A PREROUTING ! -i wlan0 -m ttl --ttl 1 -j TTL --ttl-set 64

iptables -t mangle -D FORWARD -i wlan0 -j TTL --ttl-set 64
iptables -t mangle -A FORWARD -i wlan0 -j TTL --ttl-set 64

iptables -t mangle -D OUTPUT -o wlan0 -j TTL --ttl-set 65
iptables -t mangle -A OUTPUT -o wlan0 -j TTL --ttl-set 65

ip6tables -t mangle -D PREROUTING ! -i wlan0 -m hl --hl-eq 1 -j HL --hl-set 64
ip6tables -t mangle -A PREROUTING ! -i wlan0 -m hl --hl-eq 1 -j HL --hl-set 64

ip6tables -t mangle -D FORWARD -i wlan0 -j HL --hl-set 64
ip6tables -t mangle -A FORWARD -i wlan0 -j HL --hl-set 64

ip6tables -t mangle -D OUTPUT -o wlan0 -j HL --hl-set 65
ip6tables -t mangle -A OUTPUT -o wlan0 -j HL --hl-set 65

