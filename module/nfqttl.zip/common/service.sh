#!/system/bin/sh
# Do NOT assume where your module will be located.
# ALWAYS use $MODDIR if you need to know where this script
# and module is placed.
# This will make sure your module will still work
# if Magisk change its mount point in the future
MODDIR=${0%/*}

# This script will be executed in late_start service mode

while [ ""`getprop dev.bootcomplete` != "1" ] ; do sleep 3; done


iptables -t mangle -D FORWARD -i wlan0 -j NFQUEUE --queue-num 201
iptables -t mangle -A FORWARD -i wlan0 -j NFQUEUE --queue-num 201

iptables -t mangle -D FORWARD -o wlan0 -m ttl --ttl 1 -j NFQUEUE --queue-num 201
iptables -t mangle -A FORWARD -o wlan0 -m ttl --ttl 1 -j NFQUEUE --queue-num 201


$MODDIR/system/bin/nfqttl &
