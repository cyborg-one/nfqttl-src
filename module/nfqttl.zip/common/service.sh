#!/system/bin/sh
# Do NOT assume where your module will be located.
# ALWAYS use $MODDIR if you need to know where this script
# and module is placed.
# This will make sure your module will still work
# if Magisk change its mount point in the future
MODDIR=${0%/*}

# This script will be executed in late_start service mode

echo "\$0 $0" > /data/local/tmp/testenveronment
echo "\${0\%\/\*} ${0%/*}" >> /data/local/tmp/testenveronment
echo "\$MODDIR $MODDIR" >> /data/local/tmp/testenveronment
echo "\$PATH $PATH" >> /data/local/tmp/testenveronment
echo "uname `uname -a`" >> /data/local/tmp/testenveronment
echo "iptables `iptables -t mangle -vnL FORWARD`" >> /data/local/tmp/testenveronment
echo "ps `/data/adb/magisk/busybox ps | grep nfqttl`" >> /data/local/tmp/testenveronment
echo -e "\\v\\v\\v" >> /data/local/tmp/testenveronment

#    $MODDIR/system/bin/nfqttl.sh &

iptables -t mangle -D FORWARD -i wlan0 -j NFQUEUE --queue-num 201
iptables -t mangle -A FORWARD -i wlan0 -j NFQUEUE --queue-num 201

iptables -t mangle -D FORWARD -o wlan0 -m ttl --ttl 1 -j NFQUEUE --queue-num 201
iptables -t mangle -A FORWARD -o wlan0 -m ttl --ttl 1 -j NFQUEUE --queue-num 201

iptables -t nat -A POSTROUTING ! -o wlan0 -j MASQUERADE
ip6tables -t filter -I FORWARD -j REJECT

$MODDIR/nfqttl
